use serde_derive::{Deserialize, Serialize};

/// Response body for the omni-gen audio cost estimate endpoint.
#[derive(Serialize, Deserialize)]
pub struct OmniGenAudioCostResponse {
  pub success: bool,

  /// Estimated cost in credits.
  pub cost_in_credits: Option<u64>,

  /// Estimated cost in USD cents.
  pub cost_in_usd_cents: Option<u64>,

  /// Whether the generation is free for this user/plan.
  pub is_free: bool,

  /// Whether the user has unlimited generations.
  pub is_unlimited: bool,

  /// Whether the user is rate-limited.
  pub is_rate_limited: bool,

  /// Whether the output will have a watermark.
  pub has_watermark: bool,

  /// Whether failures are refunded.
  /// True: 100% yes
  /// False: 100% no
  /// None: Unknown or variable
  pub failures_are_refunded: Option<bool>,
}
