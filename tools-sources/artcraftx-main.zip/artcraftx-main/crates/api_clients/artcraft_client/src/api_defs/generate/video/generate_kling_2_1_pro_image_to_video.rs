use serde::{Deserialize, Serialize};
use crate::tokens::generic_inference_jobs::InferenceJobToken;
use sqlite_identifiers::ids::media_file_token::MediaFileToken;

pub const GENERATE_KLING_2_1_PRO_IMAGE_TO_VIDEO_URL_PATH: &str = "/v1/generate/video/kling_2.1_pro_image_to_video";

#[derive(Serialize, Deserialize)]
pub struct GenerateKling21ProImageToVideoRequest {
  /// Idempotency token to prevent duplicate requests.
  pub uuid_idempotency_token: String,
  
  /// Source of the image file to convert to video.
  /// It must be an image.
  pub media_file_token: Option<MediaFileToken>,

  /// Optional.
  /// Image media file; the image to remove the background from.
  pub end_frame_image_media_token: Option<MediaFileToken>,
  
  /// Optional text prompt.
  pub prompt: Option<String>,
  
  /// Optional: aspect ratio of the generated video.
  pub aspect_ratio: Option<GenerateKling21ProAspectRatio>,

  /// Optional: aspect ratio of the generated video.
  pub duration: Option<GenerateKling21ProDuration>,
}

#[derive(Copy, Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum GenerateKling21ProAspectRatio {
  /// 16:9 aspect ratio
  WideSixteenNine,
  /// 9:16 aspect ratio
  TallNineSixteen,
  /// 1:1 aspect ratio
  Square,
}

#[derive(Copy, Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum GenerateKling21ProDuration {
  FiveSeconds,
  TenSeconds,
}

#[derive(Serialize, Deserialize)]
pub struct GenerateKling21ProImageToVideoResponse {
  pub success: bool,
  pub inference_job_token: InferenceJobToken,
}
